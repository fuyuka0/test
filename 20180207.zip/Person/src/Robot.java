/**
 * 
 */

/**
 * @author testuser
 *
 */
public class Robot {

	public int age = 0;
	
	public static void main(String[] args) {
		Test taro = new Test(); 
		taro.name = "山田太郎";
		System.out.println(taro.name);
		taro.talk();
		taro.walk();
		taro.run();

	}

}
