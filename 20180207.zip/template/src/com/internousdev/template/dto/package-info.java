/**
 * 
 */
/**
 * @author testuser
 *
 */
package com.internousdev.template.dto;