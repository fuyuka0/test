/**
 *
 */

/**
 * @author testuser
 *
 */
public class Cupsule {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person taro = new Person("山田太郎",20);
		System.out.println(taro.getName());
		System.out.println(taro.getAge());

	}

}
