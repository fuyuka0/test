/**
 *
 */

/**
 * @author testuser
 *
 */
public interface Mp3Playaer {

	public abstract void play();

	public abstract void stop();

	public abstract void next();

	public abstract void back();

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ

	}

}
