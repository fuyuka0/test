/**
 *
 */

/**
 * @author testuser
 *
 */
public class Person {

	public String name = null;
	public int age = 0;

	public static void main(String[] args) {


	}

}
