/**
 *
 */

/**
 * @author testuser
 *
 */
public class Android {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SmartPhone android = new SmartPhone();
		android.play();
		android.stop();
		android.next();
		android.back();
		android.call();
		android.mail();
		android.photo();
		android.internet();

	}

}
