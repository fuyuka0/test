/**
 * 
 */
/**
 * @author testuser
 *
 */
package com.internousdev.login.dto;