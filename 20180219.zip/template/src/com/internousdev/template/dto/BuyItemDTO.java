package com.internousdev.template.dto;

public class BuyItemDTO {

	private int id;
	private String item_name;
	private String item_price;

	public int getId(){
		return id;
	}

	public void setId(int id){
		this.id =id;

	}

	public String getItemName(){
		return item_name;
	}

	public void setItemName(String item_name){
		this.item_name = item_name;
	}

	public String getItemPrice(){
		return item_price;
	}

	public void setItemPrice(String item_price){
		this.item_price = item_price;
	}




}
