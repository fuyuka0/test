/**
 * 
 */

/**
 * @author testuser
 *
 */
public class Test {
	public String name = null;
	public void talk(){
		System.out.println(this.name + "が話す");
	}
	public void walk(){
		System.out.println(this.name + "が歩く");
	}
	public void run(){
		System.out.println(this.name + "が走る");
	}

	
	public static void main(String[] args) {
		Person jiro = new Person();
		Person hanako = new Person();
		Person yuka = new Person();
		jiro.name = "木村次郎";
		jiro.age = 18;
		System.out.println(jiro.name);
		System.out.println(jiro.age);
		hanako.name = "鈴木花子";
		hanako.age = 16;
		System.out.println(hanako.name);
		System.out.println(hanako.age);
		yuka.name = "藤間由佳";
		yuka.age = 27;
		yuka.phoneNumber = "000";
		yuka.address = "東京";
		yuka.seibetu = "女";
		System.out.println(yuka.name);
		System.out.println(yuka.age);
		System.out.println(yuka.address);
		System.out.println(yuka.phoneNumber);
		System.out.println(yuka.seibetu);
		jiro.talk();
		jiro.walk();
		jiro.run();
		Robot aibo  = new Robot();
		Robot asimo  = new Robot();
		Robot pepper  = new Robot();
		Robot doraemon  = new Robot();
		aibo.age = 0;
		asimo.age = 1;
		pepper.age = 2;
		doraemon.age = 3;
		System.out.println(aibo.age);
		System.out.println(asimo.age);
		System.out.println(pepper.age);
		System.out.println(doraemon.age);



	}

}
